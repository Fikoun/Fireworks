package game;

public class cords 
{
	
	int x, y;
	public cords(int x, int y)
	{
		this.x =x;
		this.y =y;
	}

}
