package game;

import java.util.ArrayList;

public class Smoke
{

	public ArrayList<cords> cords = new ArrayList<cords>();

	
}
