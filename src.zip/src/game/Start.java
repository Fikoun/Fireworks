package game;

public class Start {

	public static void main(String[] args) 
	{
		
		new FireWorkGame();	
		
	}

}
